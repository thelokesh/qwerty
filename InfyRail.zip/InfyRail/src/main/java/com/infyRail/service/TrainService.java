package com.infyRail.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infyRail.dto.TrainDTO;
import com.infyRail.entity.TrainEntity;
import com.infyRail.repo.TrainRepo;

@Service
public class TrainService {

	@Autowired
	TrainRepo trainRepo;
	
	public String createTrain(TrainDTO trainDTO) {
		TrainEntity en=TrainDTO.changesTo(trainDTO);
		trainRepo.saveAndFlush(en);
		System.out.println("id "+en.getId());
		return Integer.toString(en.getId());
	}
	
	public String updateTrain(String id, String fare) {
		
		Optional<TrainEntity> en=trainRepo.findById(Integer.parseInt(id));
		try {
			TrainEntity tent=en.get();
			tent.setFare(Double.parseDouble(fare));
			trainRepo.saveAndFlush(tent);
			return "Success: Fare gets Updated";
		} catch (Exception e) {
			return "Failed: Could not update the fare";
			// TODO: handle exception
		}
	}
	
	
	
}

//{
//"source": "Ludhiana",
//"destination": "Patna",
//"trainList":[{
//    "id":"1",
//    "trainName":"AZ",
//    "arrivalTime":"8:30 AM",
//    "departureTime":"09:00 PM",
//    "fare":"3000.00"
//},{
//    "id":"2",
//    "trainName":"BZ",
//    "arrivalTime":"9:30 AM",
//    "departureTime":"06:00 PM",
//    "fare":"2100.00"
//}]
//}